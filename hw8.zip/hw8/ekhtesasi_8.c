// mobina najafi
// 40223081


#include<stdio.h>
#include<stdlib.h>

struct time{
    int min;
    int sec;
};

struct runner{
    char firstName[50];
    char lastName[50];
    char ID[20];
    struct time *record;
    struct time runningTime;
};



int main(){
    
    int n;
    printf("enter the number of runners:\n");
    scanf("%d",&n);
    struct runner runners[n];
    printf("enter runners informations:\n");
    
    for(int i=0; i<n ; i++){
      
        printf("\nfirstName:");
        scanf("%s",runners[i].firstName);
        printf("lastName:");
        scanf("%s",runners[i].lastName);
        printf("ID:");
        scanf("%s",runners[i].ID);
        printf("record:");
        runners[i].record=(struct time *)malloc(sizeof(struct time));
        scanf("%d %d",&runners[i].record->min,&runners[i].record->sec);
        printf("runningTime:");
        scanf("%d %d",&runners[i].runningTime.min,&runners[i].runningTime.sec);
    }

    
    int winner=0;
    for (int i=0 ; i<n ; i++){
        if(runners[0].runningTime.min*60+runners[0].runningTime.sec > runners[i].runningTime.min*60+runners[i].runningTime.sec)
            winner=i;

    }
    
    

    printf("\nthe winner of this contest is %s !!!\n\n",runners[winner].firstName);

    if (runners[winner].runningTime.min*60+runners[winner].runningTime.sec < runners[winner].record->min*60+runners[winner].record->sec)
        printf("the winner has broken his/her own record!!\n\n");
    else    
        printf("the winner has not broken his/her own record\n\n");

    int bestRecord=0;
    for (int i=0 ; i<n ; i++){
        if(runners[0].record->min*60+runners[0].record->sec > runners[i].record->min*60+runners[i].record->sec)
            bestRecord=i;

    }
    
    
    if(bestRecord==winner)
        printf("the winner has broken the record of other runners!!\n");
    else
        printf("the winner has not broken the record of other runners\n ");


    
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            int timeI = runners[i].runningTime.min * 60 + runners[i].runningTime.sec;
            int timeJ = runners[j].runningTime.min * 60 + runners[j].runningTime.sec;

            if (timeI > timeJ) {
            
                struct runner temp = runners[i];
                runners[i] = runners[j];
                runners[j] = temp;
        }
    }
    }
   
    

    printf("\nList of Competitors in order of their record in this race:\n\n");
    printf("%-20s %-20s %-20s %-30s %-30s\n", "First Name", "Last Name", "ID", "Running Time", "Record");
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("%-20s %-20s %-20s %d min %d sec %-17c %d min %d sec\n", runners[i].firstName,
           runners[i].lastName, runners[i].ID, runners[i].runningTime.min, runners[i].runningTime.sec,' ',
           runners[i].record->min, runners[i].record->sec);
    }


}

